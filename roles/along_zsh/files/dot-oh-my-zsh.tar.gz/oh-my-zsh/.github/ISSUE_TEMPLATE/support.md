---
name: Support
about: Request support for any problem you're having with Oh My Zsh
title: ''
labels: 'Type: support'
assignees: ''

---

<!--
1. Try to make sure the issue is due to Oh My Zsh
2. Include as much information as possible
-->
