## textastic

Plugin for Textastic, a text and code editor for Mac OS X

### Requirements

 * [Textastic](https://www.textasticapp.com/mac.html)

### Usage

 * If `tt` command is called without an argument, launch Textastic

 * If `tt` is passed a directory, cd to it and open it in Textastic

 * If `tt` is passed a file, open it in Textastic
